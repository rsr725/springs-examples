package aspectJ.xml.com.aop.around;

import org.aspectj.lang.ProceedingJoinPoint;


public class TrackOperationAround{
	public void myAdvice(ProceedingJoinPoint pjp ) throws Throwable{
		System.out.println("Additional Concern Before calling actual method");
		Object object = pjp.proceed();
		System.out.println("Additional Concern After calling actual method");
	}
}
