package aspectJ.xml.com.aop.afterthrowing;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;


public class TrackOperationAfterThrowing{
	public void myAdvice(JoinPoint jp, Throwable error){
		new A().a = 10;
		System.out.println("Additional Concern");
		System.out.println("Method Signature : "+jp.getSignature());
		System.out.println("Exception is : "+error);
		System.out.println("end of after Throwing advice...");  
	}
}
