package aspectJ.xml.com.aop.afterreturning;

public class B {
	int a=0,b=0;
	public void displayInfo(){
		System.out.println("After Returning Advice example displayInfo Method B : "+(a+b));
	}
	
	public int display(){
		System.out.println("After Returning Advice example display Method B : ");
		return (a+b);
	}
	
	public int show(){
		System.out.println("After Returning Advice example show Method B : ");
		return (a+b);
	}
	
	protected int show1(){
		System.out.println("protected After Returning Advice example show Method B : ");
		return (a+b);
	}
}
