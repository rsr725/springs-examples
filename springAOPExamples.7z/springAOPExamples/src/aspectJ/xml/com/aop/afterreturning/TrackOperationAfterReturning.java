package aspectJ.xml.com.aop.afterreturning;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;


public class TrackOperationAfterReturning{
	public void myAdvice(JoinPoint jp, Object result){
		new A().a = 10;
		System.out.println("Additional Concern");
		System.out.println("Method Signature : "+jp.getSignature());
		System.out.println("Result in Advice : "+result);
		System.out.println("end of after returning advice...");  
		/*System.out.println("jp.getKind() : "+jp.getKind().toString());
		System.out.println("jp.getTarget() : "+jp.getTarget().toString());
		System.out.println("jp.getArgs() : "+jp.getArgs().toString());
		System.out.println("jp.getSourceLocation() : "+jp.getSourceLocation().toString());
		System.out.println("jp.getStaticPart() : "+jp.getStaticPart().toString());
		System.out.println("jp.FIELD_GET : "+jp.FIELD_GET);*/
	}
}
