package oldstyle.com.aop.before;

public class A {
	int a=0,b=0;
	public void displayInfo(){
		System.out.println("Before Advice example : "+(a+b));
	}
}
