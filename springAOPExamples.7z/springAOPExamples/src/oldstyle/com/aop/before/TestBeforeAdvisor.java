package oldstyle.com.aop.before;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestBeforeAdvisor {

	public static void main(String[] args) {
		Resource resource = new ClassPathResource("oldstyle/com/aop/before/applicationContext.xml");
		BeanFactory beanFactory = new XmlBeanFactory(resource);
		
		A a = beanFactory.getBean("proxy", A.class);
		a.displayInfo();

	}

}
