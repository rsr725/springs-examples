package oldstyle.com.aop.after;

public class A {
	int a=0,b=0;
	public void displayInfo(){
		System.out.println("After Advice example : "+(a+b));
	}
}
