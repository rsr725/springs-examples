package oldstyle.com.aop.throwadvice;

public class Validate {
	public void validate(int age)throws Exception{
		if(age<18){
			throw new ArithmeticException("Not valid for Vote!!!");
		}else{
			System.out.println("Vote Confirmed for BJP");
		}
	}
}
