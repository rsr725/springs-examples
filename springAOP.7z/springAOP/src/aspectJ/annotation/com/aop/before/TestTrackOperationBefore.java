package aspectJ.annotation.com.aop.before;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestTrackOperationBefore {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("aspectJ/annotation/com/aop/before/applicationContext.xml");
		A a = (A)context.getBean("oA");
		System.out.println("Calling DisplayInfo");
		a.displayInfo();
		
		System.out.println("Calling Display");
		a.display();
		
		System.out.println("Calling Show");
		a.show();
		
		System.out.println("Calling Show1");
		a.show1();
		
		System.out.println("#############################################################################");
		B b = (B)context.getBean("oB");
		System.out.println("Calling DisplayInfo B ");
		b.displayInfo();
		
		System.out.println("Calling Display B ");
		b.display();
		
		System.out.println("Calling Show B ");
		b.show();
		
		System.out.println("Calling Show1 B ");
		b.show1();
	}

}
