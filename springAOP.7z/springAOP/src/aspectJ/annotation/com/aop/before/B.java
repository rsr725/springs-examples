package aspectJ.annotation.com.aop.before;

public class B {
	int a=0,b=0;
	public void displayInfo(){
		System.out.println("Before Advice example displayInfo Method B : "+(a+b));
	}
	
	public int display(){
		System.out.println("Before Advice example display Method B : ");
		return (a+b);
	}
	
	public int show(){
		System.out.println("Before Advice example show Method B : ");
		return (a+b);
	}
	
	protected int show1(){
		System.out.println("protected Before Advice example show Method B : ");
		return (a+b);
	}
}
