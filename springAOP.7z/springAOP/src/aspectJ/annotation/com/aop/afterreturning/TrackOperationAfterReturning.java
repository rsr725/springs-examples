package aspectJ.annotation.com.aop.afterreturning;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class TrackOperationAfterReturning{
	//@AfterReturning(pointcut = "execution(* *.*(..))", returning= "result") //It will be applied on all classes all method with concern
	//@AfterReturning(pointcut = "execution(public * *(..))", returning= "result") //It will be applied on all classes public method with concern
	//@AfterReturning(pointcut = "execution(* A.*(..))", returning= "result") //It will be applied on A class All method with concern
	//@AfterReturning(pointcut = "execution(* A.d*(..))", returning= "result") //It will be applied on A class All method which is starting from d with concern
	//@AfterReturning(pointcut = "execution(* *.d*(..))", returning= "result")  //It will be applied on All classes All method which is starting from d with concern
	//@AfterReturning(pointcut = "execution(* *.display(..))", returning= "result") //It will be applied on All classes only display method with concern
	//@AfterReturning(pointcut = "execution(int A.*(..))", returning= "result") //It will be applied on A class All method which is returning int with concern if method exist
	@AfterReturning(pointcut = "execution(void A.*(..))", returning= "result")  //It will be applied on A class All method which is returning nothing with concern if method exist
	public void myAdvice(JoinPoint jp, Object result){
		new A().a = 10;
		System.out.println("Additional Concern");
		System.out.println("Method Signature : "+jp.getSignature());
		System.out.println("Result in Advice : "+result);
		System.out.println("end of after returning advice...");  
	}
}
