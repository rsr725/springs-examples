package aspectJ.annotation.com.aop.afterthrowing;

public class B {
	int a=0,b=0;
	public void displayInfo(int age)throws Exception{
		System.out.println("After Throwing Advice example displayInfo Method B : "+(a+b));
		if(age<18){
			throw new ArithmeticException("Not Valid!!!");
		}else{
			System.out.println("Thanks For Voe...");
		}
	}
	
	protected void show1(int age)throws Exception{
		System.out.println("protected After Throwing Advice example show Method B : ");
		if(age<18){
			throw new ArithmeticException("Not Valid!!!");
		}else{
			System.out.println("Thanks For Voe...");
		}
	}
}
