package aspectJ.annotation.com.aop.afterthrowing;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestTrackOperationAfterThrowing {

	public static void main(String[] args) throws Exception {
		ApplicationContext context = new ClassPathXmlApplicationContext("aspectJ/annotation/com/aop/afterthrowing/applicationContext.xml");
		A a = (A)context.getBean("oA");
		a.a = 15;
		a.b = 12;
		System.out.println("Calling DisplayInfo A ");
		a.displayInfo(19);
		
		
		System.out.println("Calling Show1 A ");
		a.show1(19);
		System.out.println("#############################################################################");
		B b = (B)context.getBean("oB");
		System.out.println("Calling DisplayInfo B ");
		b.displayInfo(15);
		
		
		System.out.println("Calling Show1 B ");
		b.show1(19);
	}

}
