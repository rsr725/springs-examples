package aspectJ.annotation.com.aop.around;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class TrackOperationAround{
	@Pointcut("execution(* *.*(..))") //It will be applied on all classes all method with concern
	//@Pointcut("execution(public * *(..))") //It will be applied on all classes public method with concern
	//@Pointcut("execution(* A.*(..))") //It will be applied on A classes All method with concern
	//@Pointcut("execution(* A.d*(..))") //It will be applied on A classes All method which is starting from d with concern
	//@Pointcut("execution(* *.d*(..))") //It will be applied on All classes All method which is starting from d with concern
	//@Pointcut("execution(* *.display(..))") //It will be applied on All classes only display method with concern
	//@Pointcut("execution(int A.*(..))") //It will be applied on A classes All method which is returning int with concern if method exist
	//@Pointcut("execution(void A.*(..))") //It will be applied on A classes All method which is returning nothing with concern if method exist
	public void k(){}
	
	@Around("k()")
	public void myAdvice(ProceedingJoinPoint pjp ) throws Throwable{
		System.out.println("Additional Concern Before calling actual method");
		Object object = pjp.proceed();
		System.out.println("Additional Concern After calling actual method");
	}
}
