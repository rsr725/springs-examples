package aspectJ.annotation.com.aop.around;

public class B {
	int a=0,b=0;
	public void displayInfo(){
		System.out.println("Around Advice example displayInfo Method B : "+(a+b));
	}
	
	public int display(){
		System.out.println("Around Advice example display Method B : ");
		return (a+b);
	}
	
	public int show(){
		System.out.println("Around Advice example show Method B : ");
		return (a+b);
	}
	
	protected int show1(){
		System.out.println("protected Around Advice example show Method B : ");
		return (a+b);
	}
}
