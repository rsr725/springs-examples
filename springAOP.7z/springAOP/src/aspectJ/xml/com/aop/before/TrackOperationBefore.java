package aspectJ.xml.com.aop.before;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;


public class TrackOperationBefore{
	public void myAdvice(JoinPoint jp){
		System.out.println("Additional Concern");
		System.out.println("Method Signature : "+jp.getSignature());
	}
}
