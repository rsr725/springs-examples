package aspectJ.xml.com.aop.afterreturning;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestTrackOperationAfterReturning {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("aspectJ/xml/com/aop/afterreturning/applicationContext.xml");
		A a = (A)context.getBean("oA");
		a.a = 10;
		System.out.println("Calling Display");
		System.out.println(a.display());
		
		System.out.println("Calling Show");
		System.out.println(a.show());
		
		System.out.println("Calling Show1");
		System.out.println(a.show1());
		
		System.out.println("#############################################################################");
		B b = (B)context.getBean("oB");

		System.out.println("Calling Display B ");
		System.out.println(b.display());
		
		System.out.println("Calling Show B ");
		System.out.println(b.show());
		
		System.out.println("Calling Show1 B ");
		System.out.println(b.show1());
	}

}
