package aspectJ.xml.com.aop.after;

public class A {
	int a=0,b=0;
	public void displayInfo(){
		System.out.println("After Advice example displayInfo Method: "+(a+b));
	}
	
	public int display(){
		System.out.println("After Advice example display Method: ");
		return (a+b);
	}
	
	public int show(){
		System.out.println("After Advice example show Method: ");
		return (a+b);
	}
	
	protected int show1(){
		System.out.println("protected After Advice example show Method: ");
		return (a+b);
	}
}
