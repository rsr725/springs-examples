package aspectJ.xml.com.aop.after;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;


public class TrackOperationAfter{
	public void myAdvice(JoinPoint jp){
		System.out.println("Additional Concern");
		System.out.println("Method Signature : "+jp.getSignature());
	}
}
