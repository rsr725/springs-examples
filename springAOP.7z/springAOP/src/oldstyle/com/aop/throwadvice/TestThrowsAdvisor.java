package oldstyle.com.aop.throwadvice;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestThrowsAdvisor {

	public static void main(String[] args) {
		Resource resource = new ClassPathResource("oldstyle/com/aop/throwadvice/applicationContext.xml");
		BeanFactory beanFactory = new XmlBeanFactory(resource);
		
		Validate v = beanFactory.getBean("proxy", Validate.class);
		try {
			v.validate(121);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
