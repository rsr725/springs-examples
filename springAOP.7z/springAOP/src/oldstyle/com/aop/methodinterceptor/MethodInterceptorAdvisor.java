package oldstyle.com.aop.methodinterceptor;

import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;

public class MethodInterceptorAdvisor implements MethodInterceptor{

	@Override
	public Object invoke(MethodInvocation arg0) throws Throwable {
		Object obj;
		System.out.println("additional concern Before Method Interceptor actual logic");
		A a = new A();
		a.a = 10;
		a.b = 15;
		a.displayInfo();
		obj = arg0.proceed();
		System.out.println("additional concern After Method Interceptor actual logic");
		A a1 = new A();
		a1.a = 15;
		a1.b = 15;
		a1.displayInfo();
		return obj;
	}

}
