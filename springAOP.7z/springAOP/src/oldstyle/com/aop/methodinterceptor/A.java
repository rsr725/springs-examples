package oldstyle.com.aop.methodinterceptor;

public class A {
	int a=0,b=0;
	public void displayInfo(){
		System.out.println("Method Interceptor Advice example : "+(a+b));
	}
}
